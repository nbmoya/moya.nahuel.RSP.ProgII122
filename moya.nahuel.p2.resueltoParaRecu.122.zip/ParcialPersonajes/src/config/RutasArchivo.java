package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface RutasArchivo {
    
    String BASE = "src/resources/";
    
    String FILE_CSV = "personajes.csv";
    String FILE_BIN = "personajes.dat";
    
    static Path getPathCSV() {
        return Paths.get(BASE, FILE_CSV);
    }
    
    static Path getPathBIN() {
        return Paths.get(BASE, FILE_BIN);
    }
    
    static String getPathCSVString() {
        return getPathCSV().toString();
    }
    
    static String getPathBINString() {
        return getPathBIN().toString();
    }
}