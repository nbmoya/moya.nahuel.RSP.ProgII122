package persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import model.CSVSerializable;

public interface PersistenciaPersonajes {

    static <T extends CSVSerializable> void guardarCSV(List<T> lista, String path) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            for (T item : lista) {
                escritor.write(item.toCSV()); 
                escritor.newLine();
            }
        }
    }

    static <T> List<T> cargarCSV(String path, Function<String, T> transformadora) throws IOException {
        List<T> toReturn = new ArrayList<>();
        
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    T item = transformadora.apply(linea);
                    toReturn.add(item);
                }
            }
        }
        return toReturn;
    }

    static <T> void serializar(List<T> lista, String path) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
        }
    }

    static <T> List<T> deserializar(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            return (List<T>) entrada.readObject();
        }
    }
}