package parcialpersonajes;

import config.RutasArchivo;
import java.io.IOException;
import model.Personaje;
import model.RolPersonaje;
import model.ColeccionPersonajes;

public class Parcial2 {

    public static void main(String[] args) {
        try {
            ColeccionPersonajes<Personaje> coleccion = new ColeccionPersonajes<>();
            coleccion.agregar(new Personaje(1, "Arthas", "Blizzard",
                    RolPersonaje.TANQUE));
            coleccion.agregar(new Personaje(2, "Zelda Mage", "Nintendo",
                    RolPersonaje.MAGO));
            coleccion.agregar(new Personaje(3, "Shadow Archer", "Sega",
                    RolPersonaje.ARQUERO));
            coleccion.agregar(new Personaje(4, "MedBot 2.0", "Valve",
                    RolPersonaje.SANADOR));
            coleccion.agregar(new Personaje(5, "Tech Engineer", "Capcom",
                    RolPersonaje.INGENIERO));

            // Mostrar todos los personajes
            System.out.println("Personajes:");
            coleccion.paraCadaElemento(System.out::println);

            // Filtrar por rol MAGO
            System.out.println("\nPersonajes MAGO:");
            coleccion.filtrar(p -> p.getRol() == RolPersonaje.MAGO)
                    .forEach(System.out::println);

            // Filtrar por nombre que contenga "Shadow"
            System.out.println("\nPersonajes que contienen 'Shadow':");
            coleccion.filtrar(p -> p.getNombre().contains("Shadow"))
                    .forEach(System.out::println);

            // Ordenar por ID (orden natural)
            System.out.println("\nPersonajes ordenados por ID:");
            coleccion.ordenar((p1, p2) -> p1.compareTo(p2));
            coleccion.paraCadaElemento(System.out::println);

            // Ordenar personajes por nombre
            System.out.println("\nPersonajes ordenados por nombre:");
            coleccion.ordenar((p1, p2) -> p1.getNombre().compareTo(p2.getNombre()));
            coleccion.paraCadaElemento(System.out::println);

            // Guardar en archivo binario
            coleccion.guardarEnArchivo(RutasArchivo.getPathBINString());

            // Cargar desde archivo binario
            ColeccionPersonajes<Personaje> cargado = new ColeccionPersonajes<>();
            cargado.cargarDesdeArchivo(RutasArchivo.getPathBINString());
            System.out.println("\nPersonajes cargados desde archivo binario:");
            cargado.paraCadaElemento(System.out::println);

            // Guardar en archivo CSV
            coleccion.guardarEnCSV(RutasArchivo.getPathCSVString());

            // Cargar desde archivo CSV
            cargado.cargarDesdeCSV(RutasArchivo.getPathCSVString(), linea -> Personaje.fromCSV(linea));
            System.out.println("\nPersonajes cargados desde archivo CSV:");
            cargado.paraCadaElemento(System.out::println);
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }

    }

}
