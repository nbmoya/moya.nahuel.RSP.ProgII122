package model;


import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import persistence.PersistenciaPersonajes;

public class ColeccionPersonajes<T extends CSVSerializable> implements Serializable {

    private static final long serialVersionUID = 1L; 
    private List<T> elementos;

    public ColeccionPersonajes() {
        this.elementos = new ArrayList<>();
    }

    public void agregar(T item) {
        if (item != null) {
            elementos.add(item);
        }
    }
    
    public void eliminar(int indice) {
        validarIndice(indice);
        elementos.remove(indice);
    }
    
    public T obtener(int indice) {
        validarIndice(indice);
        return elementos.get(indice);
    }
    
    private void validarIndice(int indice) {
        if (indice < 0 || indice >= elementos.size()) {
            throw new IndexOutOfBoundsException("Índice inválido: " + indice);
        }
    }
    
    public int tamanio() {
        return elementos.size();
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T elemento : elementos) {
            accion.accept(elemento);
        }
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    public void ordenar(Comparator<? super T> criterio) {
        elementos.sort(criterio);
    }


    public void guardarEnArchivo(String path) throws IOException {
        PersistenciaPersonajes.serializar(elementos, path);
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        elementos = PersistenciaPersonajes.deserializar(path);
    }

    public void guardarEnCSV(String path) throws IOException {
        PersistenciaPersonajes.guardarCSV(elementos, path);
    }

    public void cargarDesdeCSV(String path, Function<String, T> transformadora) throws IOException {
        elementos = PersistenciaPersonajes.cargarCSV(path, transformadora);
    }
}