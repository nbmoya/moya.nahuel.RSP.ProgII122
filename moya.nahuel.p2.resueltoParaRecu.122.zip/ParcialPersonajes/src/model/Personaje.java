package model;

import java.io.Serializable;

public class Personaje implements Comparable<Personaje>, Serializable, CSVSerializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private String creador;
    private RolPersonaje rol;

    public Personaje(int id, String nombre, String creador, RolPersonaje rol) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.rol = rol;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public RolPersonaje getRol() {
        return rol;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("ID: ").append(id);
        sb.append(System.lineSeparator());

        sb.append("Nombre: ").append(nombre);
        sb.append(System.lineSeparator());

        sb.append("Creador: ").append(creador);
        sb.append(System.lineSeparator());

        sb.append("Rol: ").append(rol);
        sb.append(System.lineSeparator());
        sb.append("--------------------------");

        return sb.toString();
    }

    @Override
    public int compareTo(Personaje p) {
        return Integer.compare(id, p.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + creador + "," + rol;
    }

    public static Personaje fromCSV(String linea) {
        String[] datos = linea.split(",");

        int id = Integer.parseInt(datos[0].trim());
        String nombre = datos[1].trim();
        String creador = datos[2].trim();
        RolPersonaje rol = RolPersonaje.valueOf(datos[3].trim());

        return new Personaje(id, nombre, creador, rol);
    }
}
