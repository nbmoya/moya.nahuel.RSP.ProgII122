package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface RutasArchivo {
    

    String BASE = "src/resources/";
    
    String FILE_CSV = "inventario.csv";
    String FILE_BIN = "inventario.bin";
    String FILE_JSON = "inventario.json"; 
    
    static Path getPathCSV() {
        return Paths.get(BASE, FILE_CSV);
    }
    
    static Path getPathBIN() {
        return Paths.get(BASE, FILE_BIN);
    }
    
    static Path getPathJSON() {
        return Paths.get(BASE, FILE_JSON);
    }
    
    static String getPathCSVString() {
        return getPathCSV().toString();
    }
    
    static String getPathBINString() {
        return getPathBIN().toString();
    }
    
    static String getPathJSONString() {
        return getPathJSON().toString();
    }
}