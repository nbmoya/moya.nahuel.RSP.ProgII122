package persistence;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import model.CSVConvertible;

public interface PersistenciaJurasicos {

    static <T extends CSVConvertible> void guardarCSV(List<T> lista, String path, String header) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            
            if (header != null && !header.isEmpty()) {
                escritor.write(header);
                escritor.newLine();
            }

            for (T item : lista) {
                escritor.write(item.toCSV()); 
                escritor.newLine();
            }
        } 
    }

    static <T> List<T> cargarCSV(String path, Function<String, T> transformadora) throws IOException {
        List<T> toReturn = new ArrayList<>();
        
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;
            lector.readLine(); 

            while ((linea = lector.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    T item = transformadora.apply(linea);
                    toReturn.add(item);
                }
            }
        }
        return toReturn;
    }

    static <T> void serializar(List<T> lista, String path) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
        }
    }

    static <T> List<T> deserializar(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            return (List<T>) entrada.readObject();
        }
    }
    
    public static <T> void guardarJSON(List<T> lista, String ruta) throws Exception {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        
        try (FileWriter escritor = new FileWriter(ruta)) {
            gson.toJson(lista, escritor);
        }
    }
}