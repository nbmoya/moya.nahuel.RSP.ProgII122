package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator; 
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import persistence.PersistenciaJurasicos;

public class Inventario<T> implements Almacenable<T>, Serializable {
    
    private static final long serialVersionUID = 1L; 
    private List<T> elementos;

    public Inventario() {
        this.elementos = new ArrayList<>();
    }

    @Override
    public void agregar(T elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("Error: No se puede agregar un elemento nulo al inventario.");
        }
        elementos.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        if (criterio == null) return; 
        
        Iterator<T> it = elementos.iterator();
        while (it.hasNext()) {
            T item = it.next();
            if (criterio.test(item)) {
                it.remove();
            }
        }
    }

    @Override
    public List<T> obtenerTodos() {
        return new ArrayList<>(elementos);
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        if (criterio == null) return null;
        
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                return elemento;
            }
        }
        return null; 
    }

    @Override
    @SuppressWarnings("unchecked")
    public void ordenar() {
        if (!elementos.isEmpty() && !(elementos.get(0) instanceof Comparable)) {
             throw new IllegalStateException("Los elementos no son comparables por defecto.");
        }
        Collections.sort((List<Comparable>) elementos);
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        if (comparador != null) {
            elementos.sort(comparador);
        }
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        if (criterio == null) return resultado;

        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> resultado = new ArrayList<>();
        if (operador == null) return resultado;

        for (T elemento : elementos) {
            resultado.add(operador.apply(elemento));
        }
        return resultado;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        if (criterio == null) return 0;
        
        int contador = 0;
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                contador++;
            }
        }
        return contador;
    }


    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        String header = "id, nombre, especie, nivelPeligrosidad, anioDescubrimiento";
        PersistenciaJurasicos.guardarCSV((List<CSVConvertible>) elementos, ruta, header);
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        List<T> cargados = PersistenciaJurasicos.cargarCSV(ruta, fromCSV);
        elementos.addAll(cargados);
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        PersistenciaJurasicos.serializar(elementos, ruta);
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        elementos = PersistenciaJurasicos.deserializar(ruta);
    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        PersistenciaJurasicos.guardarJSON(elementos, ruta);
    }
}