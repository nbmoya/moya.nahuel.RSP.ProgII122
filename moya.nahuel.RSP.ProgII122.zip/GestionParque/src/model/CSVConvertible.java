package model;

@FunctionalInterface
public interface CSVConvertible {
    
    String toCSV();
}