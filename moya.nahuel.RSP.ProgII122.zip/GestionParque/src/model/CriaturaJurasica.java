package model;

import java.io.Serializable;

public class CriaturaJurasica implements Comparable<CriaturaJurasica>, Serializable, CSVConvertible {
    
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private Especie especie;
    private int nivelPeligrosidad;
    private int anioDescubrimiento;

    public CriaturaJurasica(int id, String nombre, Especie especie, int nivelPeligrosidad, int anioDescubrimiento) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.nivelPeligrosidad = nivelPeligrosidad;
        this.anioDescubrimiento = anioDescubrimiento;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Especie getEspecie() {
        return especie;
    }

    public int getNivelPeligrosidad() {
        return nivelPeligrosidad;
    }

    public int getAnioDescubrimiento() {
        return anioDescubrimiento;
    }

    public void setNivelPeligrosidad(int nivelPeligrosidad) {
        this.nivelPeligrosidad = nivelPeligrosidad;
    }
    
    @Override
    public String toString() {
        return "ID= " + id + ", Nombre= " + nombre + ", Especie= " + especie + ", Peligrosidad= " + nivelPeligrosidad + ", Año= " + anioDescubrimiento;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + nivelPeligrosidad + "," + anioDescubrimiento;
    }

    public static String toHeaderCSV() {
        return "id, nombre, especie, nivelPeligrosidad, anioDescubrimiento";
    }

    public static CriaturaJurasica fromCSV(String linea) {
        String[] datos = linea.split(",");
        
        int id = Integer.parseInt(datos[0].trim());
        String nombre = datos[1].trim();
        Especie especie = Especie.valueOf(datos[2].trim());
        int peligrosidad = Integer.parseInt(datos[3].trim());
        int anio = Integer.parseInt(datos[4].trim());
        
        return new CriaturaJurasica(id, nombre, especie, peligrosidad, anio);
    }

    @Override
    public int compareTo(CriaturaJurasica c) {
        int comparacionPeligro = Integer.compare(c.nivelPeligrosidad, nivelPeligrosidad);
        
        if (comparacionPeligro != 0) {
            return comparacionPeligro;
        }
        return Integer.compare(anioDescubrimiento, c.anioDescubrimiento);
    }
}